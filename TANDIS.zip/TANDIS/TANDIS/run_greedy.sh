#!/bin/bash

python greedy.py -dataset cora -budget 1 -lcc -save_scores